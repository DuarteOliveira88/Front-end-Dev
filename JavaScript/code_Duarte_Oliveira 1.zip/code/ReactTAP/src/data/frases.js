const frases=["O meu objetivo e aprender React para construir aps incriveis!","Fazer interfaces user friendly","ter o meu codigo optimizado"]
export default frases