const listaCompras=[{produto: "batata", quantidade:"5kg"},{produto: "paes", quantidade:"2"},{produto: "chocolate", quantidade:"1embalage"}]
export default listaCompras 