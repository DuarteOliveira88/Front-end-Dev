import { Link } from "react-router-dom";
export default function ErrorPage(){
    return <h3>Estas perdido? Volta <Link to="/">aqui</Link></h3>
}