export const LISTAPRENDAS={
 DUARTE : [{
    remetente: "mae",
    presente: "perfume",
    preco: "40€"
}],
MAE : [{
    remetente: "Duarte",
    presente: "jogo",
    preco: "60€"
}, {
    remetente: "David",
    presente: "jogo",
    preco: "30€"
}],
PAI:[]
}