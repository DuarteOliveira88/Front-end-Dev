import "./Cartoes.css"
function LinhaListaNatal(props) {
    return <h4>{props.remetente}: {props.presente} - {props.preco}</h4>
}
export default LinhaListaNatal