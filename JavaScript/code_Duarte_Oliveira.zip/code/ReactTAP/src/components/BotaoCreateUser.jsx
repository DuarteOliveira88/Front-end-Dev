export default function BotaoCreateUser({children,onSelect}){
    return(
        
          <button onClick={onSelect}>{children}</button>
        
    )
}