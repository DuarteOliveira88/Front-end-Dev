function MainGoal(props) {
    // return (
    //   <div>
    // <p>O meu objetivo e aprender React para construir aps incriveis!</p>
    // </div>
    // )
    return (<div><p>{props.frase}</p></div>)
  }

export default MainGoal