export const userData = {
    user1: { firstName: "Duarte", lastName: "Oliveira", title: "Formando" }, user2: { firstName: "Sara", lastName: "Monteiro", title: "Formadora" },
    user3: { firstName: "Antonio", lastName: "Costa", title: "Gestor" }
}
export const userData2 = [{ firstName: "Duarte", lastName: "Oliveira", title: "Formando" }, { firstName: "Sara", lastName: "Monteiro", title: "Formadora" }, { firstName: "Antonio", lastName: "Costa", title: "Gestor" }]
