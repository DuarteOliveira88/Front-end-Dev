const CONTACT={nome:"Duarte",profissao:"DEV junior",email:"exemplo_email@email.com"}
export default CONTACT