function ListaCompra(props){
    return(
        <p>{props.produto}-{props.quantidade}</p>
    )
}
export default ListaCompra