function Titulo(props) {
    return (
        <div>
        <h1>{props.Titulo}</h1>
        <p>{props.disciplina}</p>
        </div>
    )
}

export default Titulo