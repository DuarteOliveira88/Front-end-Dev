export default function Login() {
    return (
        <div>
            <p data-testid="price">$100</p>
            <button>Apply Discount </button>
        </div>
    );
}